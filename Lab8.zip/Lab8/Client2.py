import pickle
import socket
from typing import Sequence

ADDRESS = "127.0.0.1"

PORT = 5050

c = socket.socket()

c.connect((ADDRESS,PORT))  
\
print("Connect with the Server")
print("------------------------")
Data = c.recv(1024)
print("From Server :",Data.decode("utf-8"))
print("---------------------------------------------")

c.send("0x0001".encode("utf-8"))

c.send("School.txt".encode("utf-8"))

#SequencenNumber =  c.recv(1024)
#File_Size =  c.recv(1024)
#File_Names =  c.recv(1024)
OverAll = c.recv(1024)
print("First Packet :", pickle.loads(OverAll))

Size = c.recv(1024)
Size2 = pickle.loads(Size)
EndingLoop = int(Size2)/100

while EndingLoop >= 0 :
    OverAll2 = c.recv(1024)
    print("Second Packet :", pickle.loads(OverAll2))
    EndingLoop -= 1





#print("Response From Server: \n SequenceNumber : " + SequencenNumber.decode("utf-8") + " \n File Size :" + File_Size.decode("utf-8") + "\n File Name : " + File_Names.decode("utf-8"))



