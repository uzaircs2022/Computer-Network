import pickle
import socket
from typing import Sequence

ADDRESS = "127.0.0.1"

PORT = 5050

c = socket.socket()

c.connect((ADDRESS,PORT))  

print("Connect with the Server")
print("------------------------")
Data = c.recv(1024)
print("From Server :",Data.decode("utf-8"))
print("---------------------------------------------")
c.send("0x0000".encode("utf-8"))

#SequencenNumber =  c.recv(1024)
#File_Size =  c.recv(1024)
#File_Names =  c.recv(1024)
OverAll = c.recv(1024)


#print("Response From Server: \n SequenceNumber : " + SequencenNumber.decode("utf-8") + " \n File Size :" + File_Size.decode("utf-8") + "\n File Name : " + File_Names.decode("utf-8"))
print(pickle.loads(OverAll))
