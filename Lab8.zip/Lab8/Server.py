import socket
import pickle
import os

ADDRESS = "127.0.0.1"

PORT = 5050

s = socket.socket()


s.bind((ADDRESS,PORT))

s.listen(5)



File_Data = ["School.txt","Uni.txt","College.txt","Masters.txt","Bachelors.txt"]
SendingArray = []
SendingArray2 = []
Choice = []
Size = 0
Check = 0
OffSet = 0

def bytes_from_file(filename , chunksize=100):
    size = os.path.getsize('School.txt') 
    c.send(pickle.dumps(size))
    Size3 = int(size)/100

    with open(filename, "rb") as f:
        chunk = f.read(chunksize)
        while Size3 >= 0:
            SendingArray2.append("0x0012")
            SendingArray2.append("OffSet")
            SendingArray2.append(chunk)
            c.send(pickle.dumps(str(SendingArray2)))
            SendingArray2.clear()
            Size3 -= 1




print("Listening Mood")
print("--------------")
while True:
    c, addr = s.accept()

    print("Client has connected", addr)
    print("------------------------------------")

    c.send("Please send your Request:".encode("utf-8")) 

    RequestReceivedFromClient= c.recv(1024)
    DecodingClientsRequest = RequestReceivedFromClient.decode("utf-8")

    if DecodingClientsRequest == "0x0000":
        for entries in File_Data:
            Size += 1
        SendingArray.append("0x0010")
        SendingArray.append(Size)
        SendingArray.append(File_Data)
        c.send(pickle.dumps(str(SendingArray)))
        SendingArray.clear()

    elif DecodingClientsRequest == "0x0001":
        FileName = c.recv(1024)
        DecodeFileName = FileName.decode("utf-8")

        for row in File_Data:
            if row == DecodeFileName:
                Check = 1

        if Check == 1:
            SendingArray.append("0x0011")
            SendingArray.append(DecodeFileName)
            SendingArray.append("4-Bytes")
            c.send(pickle.dumps(str(SendingArray)))
            bytes_from_file(DecodeFileName)
        else:
            print("invalid File Access")





 



