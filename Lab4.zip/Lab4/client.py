import socket

ADDRESS = "127.0.0.1"

PORT = 5050

c = socket.socket()

c.connect((ADDRESS,PORT))  

print("Connect with the Server")
print("------------------------")
Data = c.recv(1024)
print("From Server :",Data.decode("utf-8"))
print("---------------------------------------------")
print("Sending Credentials")
print("--------------------")
c.send("uzair".encode("utf-8"))
c.send("uzair123".encode("utf-8"))

Data = c.recv(1024)

print("Response From Server: ",Data.decode("utf-8"))