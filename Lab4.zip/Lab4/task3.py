import socket

ADDRESS = "www.google.com"

PORT = 80

c = socket.socket()

c.connect((ADDRESS,PORT)) 

c.send("POST /index.html HTTP/1.1 \n\n".encode("utf-8"))

print("Connect with the Server")
print("------------------------")
Data = c.recv(1024)
print("From Server :",Data.decode("utf-8"))
print("---------------------------------------------")
