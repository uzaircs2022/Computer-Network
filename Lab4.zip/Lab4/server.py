import socket

ADDRESS = "127.0.0.1"

PORT = 5050

s = socket.socket()

s.bind((ADDRESS,PORT))

s.listen(5)

Clients_Data = [["uzair","uzair123"],["sajid","sajid123"],["zeemal","zeemal123"],["shani","shani123"],["hanan","hanan123"]]

print("Listening Mood")
print("--------------")

c, addr = s.accept()

print("Client has connected", addr)
print("------------------------------------")

c.send("Please send your credentials:".encode("utf-8")) 

GetUsername = c.recv(1024)
GetPassword = c.recv(1024)

UserName = GetUsername.decode("utf-8")
Password = GetPassword.decode("utf-8")

check = 0
for data in Clients_Data:
    if data[0] == UserName and data[1] == Password:
        print("Your authentication is valid")
        print("----------------------------")
        check = 1

if check == 1:
    c.send("Valid User. Please Proceed".encode("utf-8"))
else:
    c.send("Not Valid User. Please enter correct credentials".encode("utf-8"))