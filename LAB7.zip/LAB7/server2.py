import socket
import time 

ADDRESS = "127.0.0.1"

PORT = 7070



def main():
    s = socket.socket()
    s.bind((ADDRESS,PORT))  
    s.listen(5)
    print("Server 2 is listening")
    while True:
        c, addr = s.accept()
        print("Connected")
        print("------------------------")
        NameRecieved = c.recv(2048)
        StringReceivedFromMainSERVER = NameRecieved.decode("utf-8")
        FindingLength = str(len(StringReceivedFromMainSERVER))
        #joining the answer (string) and value of length
        JoinedAnswers = "Length of required string = " + FindingLength
        c.send(JoinedAnswers.encode("utf-8"))

if __name__ == "__main__":
    main()