import socket
import time 

ADDRESS = "127.0.0.1"

PORT = 6060

def main():
    S2 = socket.socket()
    S2.bind((ADDRESS,PORT))  
    S2.listen(5)
    print("Server 1 is Listening")
    while True:
        c, addr = S2.accept()
        print("Connected")
        print("------------------------")
        NameRecieved = c.recv(2048)
        StringReceivedFromMainSERVER = NameRecieved.decode("utf-8")
        if StringReceivedFromMainSERVER == StringReceivedFromMainSERVER[::-1]:
            c.send("String is Palindrome".encode("utf-8"))
        elif StringReceivedFromMainSERVER != StringReceivedFromMainSERVER[::-1]:
            c.send("String is not palindrome".encode("utf-8"))


if __name__ == "__main__":
    main()