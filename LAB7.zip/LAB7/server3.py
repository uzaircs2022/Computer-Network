import socket

ADDRESS = "127.0.0.1"

PORT = 4040

def main():
    s = socket.socket()
    s.bind((ADDRESS,PORT))  
    s.listen(5)
    print("Server 3 is listening")
    while True:
        c, addr = s.accept()
        print("Main Server : ",addr)
        print("------------------------")
        NameRecieved = c.recv(1024)
        JoinedAnswers = "Returning the same string " + NameRecieved.decode("utf-8")
        c.send(JoinedAnswers.encode("utf-8"))


if __name__ == "__main__":
    main()