import socket
from threading import Thread
from IdentityServer import Authentication
from _thread import *

ADDRESS = "127.0.0.1"
PORT = 5050
Record = []
arr = []
Check = []

def main():
    s = socket.socket()
    s.bind((ADDRESS,PORT))  
    s.listen(10)
    print("Listening to the Client")

    while True:
        c, addr = s.accept()
        print("Client Address : ",addr)
        print("____________________________")
        c.send("You Are Connected to the Server".encode("utf-8"))
        #Getting Values
        UserName = c.recv(1024)
        Password = c.recv(1024)

        Identity = Authentication(UserName.decode("utf-8"), Password.decode("utf-8"))
        ResponseFromServer4,Tok = Identity.run()

        if ResponseFromServer4 == '1':
            arr.append(UserName.decode("utf-8"))
            arr.append(Tok)
            Record.append(arr)
            c.send(Tok.encode("utf-8"))
            AgainUserName = c.recv(1024)
            AgainToken = c.recv(1024)
            Check.append(AgainUserName.decode("utf-8"))
            Check.append(AgainToken.decode("utf-8"))
            for rows in Record:
                if Check == rows:
                    c.send("Choose Any Option \n 1: To check Palindrome \n 2: To Check Length \n 3: To return Same String \n".encode("utf-8"))
                    SelectionOfClient = c.recv(1024)
                    if SelectionOfClient.decode("utf-8") == '1':
                        c.send("6060".encode("utf-8"))
                    elif SelectionOfClient.decode("utf-8") == '2':
                        c.send("7070".encode("utf-8"))
                    elif SelectionOfClient.decode("utf-8") == '3':
                        c.send("4040".encode("utf-8"))

           

       
#start_new_thread(IdentityChecker,(s,UserName.decode("utf-8"),Password.decode("utf-8"), ))

if __name__=='__main__':
    main()

