import socket
from threading import Thread
import time


SCHEME = "utf-8"

Data = [["uzair","uzair123"],["jaleel","jaleel123"]]

class Authentication(Thread):
    def __init__(self,UserName,UserPassword):
        Thread.__init__(self)
        self.UserName = UserName
        self.UserPassword = UserPassword

    def run(self):
        check = 0
        for row in Data:
            if row[0] == self.UserName and row[1] == self.UserPassword:
                print("Authentication SuccessFul")
                check = 1
                return '1', '1111'
        if check == 0:
            print("Authentication Failed")
            return '0', '0000'
                

        self.clientSocket.close()