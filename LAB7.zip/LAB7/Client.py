import socket

ADDRESS = "127.0.0.1"
PORT = 5050

c = socket.socket()

c.connect((ADDRESS,PORT))

Response = c.recv(1024)
print(Response.decode("utf-8"))
UserName = input(" Enter Your User Name = ")
UserPassword = input(" Enter Your User Password = ")
c.send(UserName.encode("utf-8"))
c.send(UserPassword.encode("utf-8"))
Token = c.recv(1024)
c.send(UserName.encode("utf-8"))
c.send(Token)
Response2 = c.recv(1024)
print(Response2.decode("utf-8"))
choice = input("Enter value = ")
c.send(choice.encode("utf-8"))
Response3 = c.recv(1024) #PORT Number
print(Response3.decode("utf-8"))
Decoding_Response4 = Response3.decode("utf-8")
c1 = socket.socket()
c1.connect((ADDRESS,int(Decoding_Response4)))
string = input("Enter Your String = ")
c1.send(string.encode("utf-8"))
c1.send(UserName.encode("utf-8"))
c1.send(Token)
Answer = c1.recv(1024) 
print(Answer.decode("utf-8"))


