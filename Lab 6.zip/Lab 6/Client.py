import socket

ADDRESS = "127.0.0.1"

PORT = 5050

SCHEME = "utf-8"

c = socket.socket()

c.connect((ADDRESS,PORT))

Response = c.recv(1024)
print(Response.decode(SCHEME))
print("___________________________________________________________________________________________________")

String = input(" Enter Your String = ")
Choice = input("Choose Any Option \n 1: To check Palindrome \n 2: To Check Length \n 3: To return Same String = ")

c.send(String.encode(SCHEME))
c.send(Choice.encode(SCHEME))


