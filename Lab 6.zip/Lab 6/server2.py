import socket
import time 

ADDRESS = "127.0.0.1"

PORT = 5052

SCHEME = "utf-8"



def main():
    s = socket.socket()
    s.bind((ADDRESS,PORT))  
    s.listen(3)
    print("Server 2 is listening")
    print("---------------------------------------------")
    while True:
        c, addr = s.accept()
        print("Main Server : ",addr)
        print("------------------------")
        String = c.recv(1024)
        Decoded_String = String.decode(SCHEME)
        Len_Decoded_String = str(len(Decoded_String))
        CombinedString = "Length of required string = " + Len_Decoded_String
        c.send(CombinedString.encode(SCHEME))

if __name__ == "__main__":
    main()