import socket
from _thread import *
#from ID_CREATION import IDCreation
#from Authentic_Authorize import Authentication
import time 

ADDRESS = "127.0.0.1"

PORT = 5050

SCHEME = "utf-8"

Servers_Ports = [5051,5052,5053]


def Communication(ServerPort,String):
    MainServerSocket = socket.socket()
    MainServerSocket.connect((ADDRESS,ServerPort))
    MainServerSocket.send(String.encode(SCHEME))
    Answer = MainServerSocket.recv(1024)
    print(Answer.decode(SCHEME))

def main():
    s = socket.socket()
    s.bind((ADDRESS,PORT))  
    s.listen(3)
    print("Listening to the Client")
    print("---------------------------------------------")

    while True:
        c, addr = s.accept()
        print("Client Address : ",addr)
        print("------------------------")
        c.send("You Are Connected to the Server".encode(SCHEME))
        String = c.recv(1024)
        Option = c.recv(1024)

        if Option.decode(SCHEME) == '1':
            start_new_thread(Communication,(Servers_Ports[0],String.decode(SCHEME), ))
        elif Option.decode(SCHEME) == '2':
            start_new_thread(Communication,(Servers_Ports[1],String.decode(SCHEME), ))
        elif Option.decode(SCHEME) == '3':
            start_new_thread(Communication,(Servers_Ports[2],String.decode(SCHEME), ))



if __name__=='__main__':
    main()

