import socket
import time 

ADDRESS = "127.0.0.1"

PORT = 5051

SCHEME = "utf-8"

def main():
    s = socket.socket()
    s.bind((ADDRESS,PORT))  
    s.listen(3)
    print("Server 1 is Listening")
    print("---------------------------------------------")
    while True:
        c, addr = s.accept()
        print("Main Server : ",addr)
        print("------------------------")
        String = c.recv(1024)
        Decoded_String = String.decode(SCHEME)
        if Decoded_String == Decoded_String[::-1]:
            c.send("String is Palindrome".encode(SCHEME))
        else:
            c.send("String is not palindrome".encode(SCHEME))


if __name__ == "__main__":
    main()