import socket

ADDRESS = "127.0.0.1"

PORT = 5050

SCHEME = "utf-8"

c = socket.socket()

c.connect((ADDRESS,PORT)) 


Data = c.recv(1024)
print(Data.decode(SCHEME))
print("---------------------------------------------")
c.send("1".encode(SCHEME))
Server_Response =  c.recv(1024)
print(Server_Response.decode(SCHEME))
print("---------------------------------------------")
c.send("Adnan".encode(SCHEME))
c.send("Adnan123".encode(SCHEME))
c.send("Faculty".encode(SCHEME))

Server_Response = c.recv(1024)

print("Reponse : ", Server_Response.decode(SCHEME))
print("---------------------------------------------")



