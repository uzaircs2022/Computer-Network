import socket

ADDRESS = "127.0.0.1"

PORT = 5050

SCHEME = "utf-8"

c = socket.socket()

c.connect((ADDRESS,PORT)) 


Data = c.recv(1024)
print(Data.decode(SCHEME))
print("---------------------------------------------")
c.send("2".encode(SCHEME))
Server_Response =  c.recv(1024)
print(Server_Response.decode(SCHEME))
print("---------------------------------------------")
c.send("uzair".encode(SCHEME))
c.send("uzair123".encode(SCHEME))

Server_Response = c.recv(1024)
print(Server_Response.decode(SCHEME))
print("---------------------------------------------")

c.send("R1".encode(SCHEME))
Server_Response = c.recv(1024)

print(Server_Response.decode(SCHEME))
print("---------------------------------------------")



