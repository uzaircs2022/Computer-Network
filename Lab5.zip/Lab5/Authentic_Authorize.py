import socket
from threading import Thread
import time


SCHEME = "utf-8"

Data = [["uzair","uzair123",["R1","R2"]],["jaleel","jaleel123",["R1","R2","R3"]]]
Arr = []

class Authentication(Thread):
    def __init__(self,ClientSocket):
        Thread.__init__(self)
        self.clientSocket = ClientSocket

    def run(self):
        print("Client Thread started .......")
        print("---------------------------------------------")
        self.clientSocket.send("Enter Your Credentials".encode(SCHEME))

        #receiving Credentials
        Name = self.clientSocket.recv(1024)
        Pass = self.clientSocket.recv(1024)
        time.sleep(1)

        #Decoding credentials
        Decode_Name = Name.decode(SCHEME)
        Decode_Pass = Pass.decode(SCHEME)
        
        check = 0
        for row in Data:
            if row[0] == Decode_Name and row[1] == Decode_Pass:
                self.clientSocket.send("Authentication SuccessFul \n--------------------------- \n Which Resource you want to access?".encode(SCHEME))
                Resource = self.clientSocket.recv(1024)
                Decode_Resource = Resource.decode(SCHEME)
                for row in Data:
                    for innerRow in row[2]:
                        if Decode_Resource == innerRow:
                            self.clientSocket.send("Access Granted".encode(SCHEME))
                            check += 1
                if check == 0:
                    self.clientSocket.send("You do not have permission to access this resource".encode(SCHEME))
            else:
                self.clientSocket.send("Invalid Credentials".encode(SCHEME))

        self.clientSocket.close()