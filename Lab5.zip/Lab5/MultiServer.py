import socket
from threading import Thread
from ID_CREATION import IDCreation
from Authentic_Authorize import Authentication
import time 

ADDRESS = "127.0.0.1"

PORT = 5050

SCHEME = "utf-8"

def main():
    s = socket.socket()
    s.bind((ADDRESS,PORT))  
    s.listen(5)
    print("Listening to the Client")
    print("---------------------------------------------")

    while True:
        c, addr = s.accept()
        print("Client Address : ",addr)
        print("------------------------")
        c.send(" Please Choose: \n 1: ID Creation \n 2: Authentication".encode(SCHEME))
        Choice = c.recv(1024)
        Decoding_Choice = Choice.decode(SCHEME)

        if Decoding_Choice == "1":
            clientThread = IDCreation(c)
            clientThread.start()
            print("Id Created")
            print("------------------------")
        elif Decoding_Choice == "2":
            clientThread = Authentication(c)
            clientThread.start()
            print("Authentication Process Completed")
            print("---------------------------------")


if __name__=='__main__':
    main()

