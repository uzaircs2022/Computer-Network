import socket
from threading import Thread
import time


SCHEME = "utf-8"

Data = [["uzair","uzair123",["R1","R2"]],["jaleel","jaleel123",["R1","R2","R3"]]]
Arr = []

class IDCreation(Thread):
    def __init__(self,ClientSocket):
        Thread.__init__(self)
        self.clientSocket = ClientSocket

    def run(self):
        print("Client Thread started .......")
        print("---------------------------------------------")
        self.clientSocket.send("Enter Your Credentials".encode(SCHEME))

        #Recieving Credentials
        Name = self.clientSocket.recv(1024)
        Pass = self.clientSocket.recv(1024)
        Role = self.clientSocket.recv(1024)
        time.sleep(1)

        #Decoding Credentials
        Decode_Name = Name.decode(SCHEME)
        Decode_Pass = Pass.decode(SCHEME)
        Decode_Role = Role.decode(SCHEME)
        Arr.append(Decode_Name)
        Arr.append(Decode_Pass)
        if Decode_Role == "Student":
            Arr.append(["R1","R2"])
        elif Decode_Role == "Faculty":
            Arr.append(["R1","R2","R3"])
        Data.append(Arr)

        self.clientSocket.send("ID Created".encode(SCHEME))

        print("Users Data")
        print("-------------------------------------------")
        for Row in Data:
            print(Row)
        self.clientSocket.close()