import socket
import pickle
import os

ADDRESS = "127.0.0.1"

PORT = 5000

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)


s.bind((ADDRESS,PORT))

#s.listen(5)



File_Data = ["School.txt","Uni.txt","College.txt","Masters.txt","Bachelors.txt"]
SendingArray = []
SendingArray2 = []
Choice = []
Size = 0
Check = 0
OffSet = 0

def bytes_from_file(filename , addr, chunksize=100):
    size = os.path.getsize('School.txt') 
    s.sendto(pickle.dumps(size),addr)
    Size3 = int(size)/100

    with open(filename, "rb") as f:
        chunk = f.read(chunksize)
        while Size3 >= 0:
            SendingArray2.append("0x0012")
            SendingArray2.append("OffSet")
            SendingArray2.append(chunk)
            s.sendto(pickle.dumps(str(SendingArray2)),addr)
            SendingArray2.clear()
            Size3 -= 1




print("Listening Mood")
print("--------------")

# c, addr = s.accept()
Data, addr = s.recvfrom(1024)

print(Data.decode("utf-8"))

print("------------------------------------")

s.sendto("Please send your Request:".encode("utf-8"),addr) 

RequestReceivedFromClient,addr= s.recvfrom(1024)
print("Client has connected", addr)

DecodingClientsRequest = RequestReceivedFromClient.decode("utf-8")


if DecodingClientsRequest == "0x0000":
    for entries in File_Data:
        Size += 1
    SendingArray.append("0x0010")
    SendingArray.append(Size)
    SendingArray.append(File_Data)
    s.sendto(pickle.dumps(str(SendingArray)),addr)
    SendingArray.clear()

elif DecodingClientsRequest == "0x0001":
    FileName,addr = s.recvfrom(1024)
    DecodeFileName = FileName.decode("utf-8")

    for row in File_Data:
        if row == DecodeFileName:
            Check = 1

    if Check == 1:
        SendingArray.append("0x0011")
        SendingArray.append(DecodeFileName)
        SendingArray.append("4-Bytes")
        s.sendto(pickle.dumps(str(SendingArray)),addr)
        bytes_from_file(DecodeFileName,addr)
    else:
        print("invalid File Access")





 



