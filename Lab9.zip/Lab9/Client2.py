import pickle
import socket
from typing import Sequence

ADDRESS = "127.0.0.1"

PORT = 5000

c = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

#c.connect((ADDRESS,PORT))  


c.sendto("Hi, UDP portocol I am.".encode("utf-8"),(ADDRESS,PORT))
print("Connect with the Server")
print("------------------------")
Data,addr = c.recvfrom(1024)
print("From Server :",Data.decode("utf-8"))
print("---------------------------------------------")

c.sendto("0x0001".encode("utf-8"),addr)

c.sendto("School.txt".encode("utf-8"),addr)

#SequencenNumber =  c.recv(1024)
#File_Size =  c.recv(1024)
#File_Names =  c.recv(1024)
OverAll,addr = c.recvfrom(1024)
print("First Packet :", pickle.loads(OverAll))

Size,addr = c.recvfrom(1024)
Size2 = pickle.loads(Size)
EndingLoop = int(Size2)/100

while EndingLoop >= 0 :
    OverAll2,addr = c.recvfrom(1024)
    print("Second Packet :", pickle.loads(OverAll2))
    EndingLoop -= 1





#print("Response From Server: \n SequenceNumber : " + SequencenNumber.decode("utf-8") + " \n File Size :" + File_Size.decode("utf-8") + "\n File Name : " + File_Names.decode("utf-8"))



